# LABs

## 088_ConsumindoAPITwitterPython

Consumindo a API do Twitter com Python

Expanda seus conhecimentos sobre Python, Banco de Dados e APIs. Para isso, vamos criar um projeto prático com o objetivo de consumir a API REST do Twitter. Nesse sentido, uma série de boas práticas e dicas foram apresentadas pelo nosso expert. Entre elas o Tweepy, que reduziu a complexidade no consumo da API do Twitter.

Python - Full-Stack - Intermediário
ESPECIALISTA
#### Guilherme Carvalho
Python Consultant, Oak Solutions
 

https://web.dio.me/lab/consumindo-a-api-do-twitter-com-python/learning/6702bea4-a270-4e56-b3cd-c320557fd4f9
